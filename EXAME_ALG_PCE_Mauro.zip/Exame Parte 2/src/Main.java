
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

public class Main {
    static Scanner in = new Scanner(System.in);
    static ArrayList<String> lista = new ArrayList<>();
    static Random rnd = new Random();
    public Main() {
    }

    public static void main(String[] args) {

        int op;
        do {
            System.out.println("Bem-vindo");
            System.out.println("Escolha uma opção");
            System.out.println("1- Ex. 01");
            System.out.println("2- Ex. 02");
            System.out.println("3- Ex. 03");
            System.out.println("4- Ex. 04");
            System.out.println("5- Ex. 05");
            System.out.println("6- Ex. 06");
            System.out.println("7- Ex. 07");
            System.out.println("8- Ex. 08");
            System.out.println("0-Sair");
            op = in.nextInt();
            if (op == 0) {
                break;
            }

            if (op == 1) {
                ex01();
            } else if (op == 2) {
                ex02();
            } else if (op == 3) {
                ex03();
            } else if (op == 4) {
                ex04();
            } else if (op == 5) {
                ex05();
            } else if (op == 6) {
                ex06();
            } else if (op == 7) {
                ex07();
            } else if (op == 8) {
                ex08();
            } else {
                System.out.println("Opção inválida");
            }
        } while (op != 0);

    }

    private static void ex07() {
        /*7. Pretende-se criar uma aplicação que calcule os N primeiros números da sucessão de Fibonacci, sendo que o
        utilizador deve indicar quantos elementos (N) pretende que sejam apresentados.
        NOTA: a Sucessão de Fibonacci, é uma sequência de números inteiros, começando normalmente por 0 e 1, na
        qual, cada termo subsequente corresponde à soma dos dois anteriores */

        System.out.println("Infelizmente nao consegui fazer!!");
    }

    private static void ex06() {
        /* 6. Pedir ao utilizador um valor par, inferior a 100 e apresentar todos os inteiros múltiplos de 5, entre 0 e esse valor.
                O pedido do valor deve manter-se até o utilizador introduzir um valor nas condições pretendidas. */

        int valor;
        while (true) {
            System.out.print("Insira um valor par inferior a 100: ");
            valor = in.nextInt();

            if (valor < 100 && valor % 2 == 0) {
                break;
            } else {
                System.out.println("Erro! Deve ser um numero par e inferior a 100.");
            }
        }
        System.out.println("Inteiros multiplos de 5 sao: " + valor);
        for (int i = 5; i < valor; i += 5) {
            System.out.println(i);
        }
        }
    private static void ex08() {


        int numero = rnd.nextInt(1, 51);
        int contar = 0;
        while (true) {
            System.out.println("Insira um número entre 1 e 50");
            int numero2 = in.nextInt();

            if (numero2 < 1 || numero2 > 50) {
                System.out.println("Não é válido o numero que inseriu");
            } else if (numero2 > numero) {
                System.out.println("Tente um número mais baixo");
                contar++;
            } else if (numero2 < numero) {
                System.out.println("Tente um número mais alto");
                contar++;
            } else {
                System.out.println("Finalmente acertou!");
                System.out.println("Número certo: " + numero);
                System.out.println("Precisou de " + (contar + 1) + " tentativas para acertar");
                break;
            }
        }
    }
    private static void ex05() {
        /*5. Crie um programa que permita ao utilizador adicionar itens a uma lista de compras (utilizando ArrayList). O
        programa deve pedir novos itens até que o utilizador insira "sair". Crie opções para inserir novos elementos,
                editar um elemento, eliminar um elemento e mostrar a lista. Sugere-se a utilização de um menu. */
        Scanner in = new Scanner(System.in);
        String item;
        while (true) {
            System.out.println("Insira Items a sua lista, quando quiser parar escreva sair:");
            item = in.nextLine();
            if (item.equals("sair")) {
                break;
            }
            lista.add(item);
        }
        int op;
        do {
            System.out.println("Bem-vindo a Loja");
            System.out.println("Escolha uma opção");
            System.out.println("1- Adicionar Novos Elementos");
            System.out.println("2- Editar um Elemento");
            System.out.println("3- Eliminar um Elemento");
            System.out.println("4- Mostrar a Lista");
            System.out.println("0- Sair");
            op = in.nextInt();
            if (op == 0) {
                break;
            }

            if (op == 1) {
                adicionar();
            } else if (op == 2) {
                editar();
            } else if (op == 3) {
                eliminar();
            } else if (op == 4) {
                mostrar();
            } else {
                System.out.println("Opção inválida");
            }
        } while (op != 0);

    }

    private static void mostrar() {
        System.out.println("--- Lista de Compras ---");
        for (int i = 0; i < lista.size(); i++) {
            System.out.println(lista.get(i));
        }
    }

    private static void eliminar() {
        mostrar();
        System.out.println("Qual o item a eliminar?");
        int pos = in.nextInt() - 1;

        if (pos >= 0 && pos < lista.size()) {
            lista.remove(pos);
            System.out.println("Item eliminado com sucesso");
        } else {
            System.out.println("Item inexistente");
        }
    }

    private static void editar() {
       mostrar();
        System.out.println("Qual o item a editar?");
        int pos = in.nextInt() - 1;

        if (pos >= 0 && pos < lista.size()) {
            in = new Scanner(System.in);

            System.out.println("Qual o novo item " + lista.get(pos));
            lista.set(pos, in.nextLine());

            System.out.println("Item editado com sucesso");
        } else {
            System.out.println("Item inexistente");
        }
    }

    private static void adicionar() {
        mostrar();
            in = new Scanner(System.in);
            System.out.println("Qual o nome do item?");
            lista.add(in.nextLine());

            System.out.println("Item inserido com sucesso!");
        }

    private static void ex04() {
       /* 4. Crie um programa que peça 5 números ao utilizador, armazene-os num array e depois pergunte ao utilizador
        por um número. Informe se o número está ou não no array. */
        
        int[] numeros = new int[5];

      
        System.out.println("Insira cinco números:");
        
        for (int i = 0; i < numeros.length; i++) {
            System.out.print("Numero " + (i + 1) + ": ");
            numeros[i] = in.nextInt();
        }
        System.out.print("Insira um numero para ver se existe no array: ");
        int verif = in.nextInt();
        boolean existe = false;
        for (int i = 0; i < numeros.length; i++) {
            if (numeros[i] == verif) {
                existe = true;
                break;
            }
        }
        if (existe) {
            System.out.println("O número " + verif + " está no array.");
        } else {
            System.out.println("O número " + verif + " não está no array.");
        }
        
    }

    private static void ex03() {
    /* 3. Crie um programa que leia o conteúdo de um ficheiro chamado entrada.txt e copie as linhas que contêm a palavra
        "importante" para outro ficheiro chamado saida.txt. Terminado o programa apresente a quantidade de linhas
        que continha a palavra “importante”. */

        String entrada = "entrada.txt";
        String saida = "saida.txt";

        int contadorlinhas = 0;
        try {
            List<String> linhas = Files.readAllLines(Paths.get(entrada));
            BufferedWriter writer = new BufferedWriter(new FileWriter(saida));
            for (String linha : linhas) {
                if (linha.contains("importante")) {
                    writer.write(linha);
                    writer.newLine();
                    contadorlinhas++;
                }
            }
            writer.close();
            System.out.println("Aparece a palavra importante em: " + contadorlinhas);
        } catch (IOException e) {
            System.err.println("Erro!! " + e.getMessage());
        }
    }


    private static void ex02() {
       /* 2. Escreva um programa que leia números do utilizador até que ele insira um número negativo. Durante o ciclo:
        a. Armazene os números em um array.
        b. Após a interrupção do ciclo, mostre os números em ordem inversa
       */
        ArrayList<Integer> numeros = new ArrayList<>();

        while (true) {
            System.out.print("Insira um número, para parar digite um NUMERO NEGATIVO (ex: -3): ");
            int numero = in.nextInt();
            if (numero < 0) {
                break;
            } else
                numeros.add(numero);
        }
        System.out.println("Os números inseridos em ordem inversa são: ");
        for (int i = numeros.size() - 1; i >= 0; i--) {
            System.out.println(numeros.get(i));
        }
    }

    private static void ex01() {
       /* 1. Crie um programa que leia 10 números inteiros do utilizador e determine:
        a. Quantos números são pares.
        b. Quantos números são ímpares.
        c. A soma de todos os números.
        d. A média de todos os números
*/
        int par = 0;
        int impar = 0;
        int soma = 0;

        System.out.println("Insira 10 numeros");
        for (int i = 0; i < 10; i++) {
            System.out.print("Insira o " + (i + 1) + "º número: ");
            int numero = in.nextInt();
            if (numero % 2 == 0) {
                par++;
            } else {
                impar++;
            }
            soma += numero;
        }
        double media = (double) soma / 10;

        System.out.println("Os números pares são: " + par);
        System.out.println("Os números impares são: " + impar);
        System.out.println("A soma de todos os números é: " + soma);
        System.out.println("A média de todos os números é: " + media);

    }
}
